#!/usr/bin/perl
use warnings;
use strict;

#scalar @ARGV = length of array = how many arguments?
#want one argument = filename
die "Need to enter a filename\n" unless scalar @ARGV==1;
#get filename
my $filename = shift;
my $duplicates = 'duplicates.txt';
#open filehandle
open (IN, '<', $filename) or die "can't open $filename\n";
open (DUP , '>' , $duplicates) or die "Can't open duplicates $duplicates\n";
#declare hash
my %tab_text;
#read lines
while ( my $line = <IN> ) {
    chomp $line;

#split
    my ($name, $colour) = split /\t/, $line;
# check key has not been seen before
    if (exists $tab_text{$name} ) {
#	die "Already seen $name\n";
	print DUP "$line\n";
	next;
    }
#assign keys & values
    $tab_text{$name} = $colour;
}
# print data
print "Here are the names and colours\n";
foreach my $k (sort keys %tab_text) {
    print "$k likes $tab_text{$k}\n";
}
close DUP;
close IN;
