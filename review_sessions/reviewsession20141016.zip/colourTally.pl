#!/usr/bin/perl 
use warnings;
use strict;

my %col = (
    'bob' => 'green',
    'femi' => 'white',
    'joe' => 'brown',
    'ryan' => 'purple',
    'scott' => 'blue',
    'simon' => 'purple',
    'sofia' => 'green',
    );
#make new hash for tallying
my %tally;
# loop around keys
foreach my $key (sort keys %col) {
# get value and
# increment key that matches color
    $tally{ $col{$key} }++;
}
# print out the tally
foreach my $k (sort keys %tally) {
    print "$k\t$tally{$k}\n";
}
